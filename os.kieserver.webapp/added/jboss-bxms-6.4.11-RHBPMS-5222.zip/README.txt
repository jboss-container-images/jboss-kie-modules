PATCH NAME:      
	RHBPMS-5222
PRODUCT NAME:
	Red Hat JBoss BPM Suite
VERSION:
	6.4.11
SHORT DESCRIPTION:
        [ONE-OFF](6.4.11) java.lang.IllegalArgumentException: object is not an instance of declaring class" error in the server.log file when BPMS 6.4.11 is installed on EAP 6.4.21

LONG DESCRIPTION:
        After upgrading EAP 6.4 to version 6.4.21, container creation fails with "java.lang.IllegalArgumentException: object is not an instance of declaring class" error


MANUAL INSTALL INSTRUCTIONS FOR ALL PLATFORMS:

	1. Backup and remove the following jar:

	   $SERVER_DEPLOYMENT_DIR/business-central.war/WEB-INF/lib/drools-compiler-6.5.0.Final-redhat-25.jar
	   
       $SERVER_DEPLOYMENT_DIR/kie-server.war/WEB-INF/lib/drools-compiler-6.5.0.Final-redhat-25.jar

	2. Unzip the file jboss-bxms-6.4.11-RHBPMS-5222.zip and copy:
	
	   jboss-bxms-6.4.11-RHBPMS-5222/drools-compiler-6.5.0.Final-redhat-25-RHBPMS-5222.jar

	to:
	
	   $SERVER_DEPLOYMENT_DIR/business-central.war/WEB-INF/lib
	   $SERVER_DEPLOYMENT_DIR/kie-server.war/WEB-INF/lib
	
ADDITIONAL INSTALL INSTRUCTIONS FOR ALL PLATFORMS:

    Find and replace drools-compiler-6.5.0.Final-redhat-25.jar with the patched 
    drools-compiler-6.5.0.Final-redhat-25-RHBPMS-5222.jar for all occurences of that file in your project.
          
MANUAL INSTALL INSTRUCTIONS FOR MAVEN BASED PROJECTS:

    1. Extract the attached jboss-bxms-6.4.11-RHBPMS-5222.zip

    2. Run the following commands to install the patch binaries to the local maven repository:
    
       $ mvn install:install-file -Dfile=drools-compiler-6.5.0.Final-redhat-25-RHBPMS-5222.jar -Dsources=drools-compiler-6.5.0.Final-redhat-25-RHBPMS-5222-sources.jar -DgroupId=org.drools -DartifactId=drools-compiler -Dversion=6.5.0.Final-redhat-25-RHBPMS-5222 -DpomFile=drools-compiler-6.5.0.Final-redhat-25-RHBPMS-5222.pom -Dpackaging=jar

    3. 	Override the original version of modified jars explicitly declaring them in <dependencyManagement> of your project pom.xml:

	    <dependency>
	      <groupId>org.drools</groupId>
	      <artifactId>drools-compiler</artifactId>
	      <version>6.5.0.Final-redhat-25-RHBPMS-5222</version>
	    </dependency>

CREATOR:
        Martin Weiler
DATE:
        6-Nov-2018
